#!/usr/bin/env sh
python3 ui.py 